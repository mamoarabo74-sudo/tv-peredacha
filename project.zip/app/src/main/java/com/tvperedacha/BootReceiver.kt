package com.tvperedacha

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** После включения телевизора приём запускается сам. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val p = context.getSharedPreferences("settings", Context.MODE_PRIVATE)
        if (p.getBoolean("receiver_enabled", false)) ReceiverService.start(context)
    }
}
