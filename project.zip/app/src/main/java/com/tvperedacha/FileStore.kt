package com.tvperedacha

import android.content.ActivityNotFoundException
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.provider.Settings
import android.webkit.MimeTypeMap
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream

/** Сохраняет полученные файлы в «Загрузки/ТВ Передача» и открывает их. */
object FileStore {
    data class Received(val name: String, val uri: Uri, val mime: String)

    const val APK_MIME = "application/vnd.android.package-archive"

    fun mimeOf(name: String): String {
        val ext = name.substringAfterLast('.', "").lowercase()
        if (ext == "apk") return APK_MIME
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
    }

    fun safeName(raw: String): String {
        val n = raw.substringAfterLast('/').substringAfterLast('\\')
            .replace(Regex("[\\u0000-\\u001f:*?\"<>|]"), "_").trim()
        return if (n.isEmpty() || n == "." || n == "..") "file" else n.take(150)
    }

    fun save(ctx: Context, rawName: String, size: Long, input: InputStream): Received {
        val name = safeName(rawName)
        val mime = mimeOf(name)
        return if (Build.VERSION.SDK_INT >= 29) {
            val resolver = ctx.contentResolver
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, name)
                put(MediaStore.Downloads.MIME_TYPE, mime)
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/TV Peredacha")
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("Не удалось создать файл")
            try {
                val out = resolver.openOutputStream(uri) ?: throw IllegalStateException("Не удалось записать файл")
                out.use { Net.copyExact(input, it, size) }
                values.clear()
                values.put(MediaStore.Downloads.IS_PENDING, 0)
                resolver.update(uri, values, null, null)
            } catch (e: Exception) {
                try {
                    resolver.delete(uri, null, null)
                } catch (x: Exception) {
                }
                throw e
            }
            Received(name, uri, mime)
        } else {
            val dir = ctx.getExternalFilesDir(null) ?: ctx.filesDir
            dir.mkdirs()
            var f = File(dir, name)
            var i = 1
            while (f.exists()) {
                val base = name.substringBeforeLast('.', name)
                val ext = if (name.contains('.')) "." + name.substringAfterLast('.') else ""
                f = File(dir, "$base ($i)$ext")
                i++
            }
            try {
                FileOutputStream(f).use { Net.copyExact(input, it, size) }
            } catch (e: Exception) {
                f.delete()
                throw e
            }
            val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", f)
            Received(f.name, uri, mime)
        }
    }

    fun viewIntent(r: Received): Intent =
        Intent(Intent.ACTION_VIEW)
            .setDataAndType(r.uri, r.mime)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)

    /** Открывает файл: видео — в плеере, фото — в галерее, APK — устанавливает. */
    fun open(ctx: Context, r: Received) {
        if (r.mime == APK_MIME && Build.VERSION.SDK_INT >= 26 &&
            !ctx.packageManager.canRequestPackageInstalls()
        ) {
            try {
                ctx.startActivity(
                    Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + ctx.packageName))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
                Toast.makeText(ctx, "Разрешите установку, потом нажмите на файл ещё раз", Toast.LENGTH_LONG).show()
                return
            } catch (e: Exception) {
                // На некоторых ТВ такого экрана нет — пробуем установить сразу.
            }
        }
        try {
            ctx.startActivity(viewIntent(r))
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(ctx, "Нет приложения, чтобы открыть этот файл. Он сохранён в «Загрузки».", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(ctx, "Не удалось открыть: " + (e.message ?: ""), Toast.LENGTH_LONG).show()
        }
    }
}
