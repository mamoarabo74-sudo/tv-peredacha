package com.tvperedacha

import android.app.Activity
import android.app.UiModeManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.os.Bundle

/** Сам решает: на телевизоре — приём, на телефоне — отправка. */
class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val ui = getSystemService(Context.UI_MODE_SERVICE) as UiModeManager
        val isTv = ui.currentModeType == Configuration.UI_MODE_TYPE_TELEVISION ||
            packageManager.hasSystemFeature(PackageManager.FEATURE_LEANBACK)
        val target = when (prefs().getString("mode", null)) {
            "recv" -> ReceiverActivity::class.java
            "send" -> SenderActivity::class.java
            else -> if (isTv) ReceiverActivity::class.java else SenderActivity::class.java
        }
        startActivity(Intent(this, target))
        finish()
    }
}
