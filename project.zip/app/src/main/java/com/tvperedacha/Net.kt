package com.tvperedacha

import android.content.Context
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import android.provider.Settings
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.Inet4Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.Socket
import java.net.SocketTimeoutException

/** Простой протокол: телефон находит ТВ по UDP и отправляет файлы по TCP. */
object Net {
    const val TCP_PORT = 47811
    const val UDP_PORT = 47812
    const val MAGIC = "TVPEREDACHA1"
    const val FIND = "TVPEREDACHA_FIND"
    const val HERE = "TVPEREDACHA_HERE"

    data class Tv(val name: String, val host: String)
    data class FileInfo(val uri: Uri, val name: String, val size: Long)

    fun deviceName(ctx: Context): String {
        val n = try {
            Settings.Global.getString(ctx.contentResolver, "device_name")
        } catch (e: Exception) {
            null
        }
        return if (n.isNullOrBlank()) Build.MODEL ?: "Телевизор" else n
    }

    fun localIps(): List<String> = try {
        NetworkInterface.getNetworkInterfaces().toList()
            .filter { it.isUp && !it.isLoopback }
            .flatMap { it.inetAddresses.toList() }
            .filterIsInstance<Inet4Address>()
            .mapNotNull { it.hostAddress }
    } catch (e: Exception) {
        emptyList()
    }

    private fun broadcastAddresses(): List<InetAddress> {
        val list = mutableListOf<InetAddress>()
        try {
            list.add(InetAddress.getByName("255.255.255.255"))
            for (ni in NetworkInterface.getNetworkInterfaces()) {
                if (!ni.isUp || ni.isLoopback) continue
                for (ia in ni.interfaceAddresses) {
                    val b = ia.broadcast
                    if (b != null) list.add(b)
                }
            }
        } catch (e: Exception) {
        }
        return list.distinct()
    }

    /** Ищет телевизоры в локальной сети. Вызывать не из главного потока. */
    fun discover(timeoutMs: Long = 1500): List<Tv> {
        val found = LinkedHashMap<String, Tv>()
        try {
            DatagramSocket().use { ds ->
                ds.broadcast = true
                ds.soTimeout = 250
                val data = FIND.toByteArray(Charsets.UTF_8)
                repeat(2) {
                    for (a in broadcastAddresses()) {
                        try {
                            ds.send(DatagramPacket(data, data.size, a, UDP_PORT))
                        } catch (e: Exception) {
                        }
                    }
                }
                val end = System.currentTimeMillis() + timeoutMs
                val buf = ByteArray(512)
                while (System.currentTimeMillis() < end) {
                    val p = DatagramPacket(buf, buf.size)
                    try {
                        ds.receive(p)
                    } catch (e: SocketTimeoutException) {
                        continue
                    }
                    val msg = String(p.data, 0, p.length, Charsets.UTF_8)
                    val host = p.address?.hostAddress ?: continue
                    if (msg.startsWith(HERE)) {
                        found[host] = Tv(msg.substringAfter("|", "Телевизор"), host)
                    }
                }
            }
        } catch (e: Exception) {
        }
        return found.values.toList()
    }

    fun queryInfo(ctx: Context, uri: Uri): FileInfo {
        var name: String? = null
        var size = -1L
        try {
            ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val si = c.getColumnIndex(OpenableColumns.SIZE)
                    if (ni >= 0) name = c.getString(ni)
                    if (si >= 0 && !c.isNull(si)) size = c.getLong(si)
                }
            }
        } catch (e: Exception) {
        }
        val finalName = name ?: (uri.lastPathSegment?.substringAfterLast('/') ?: "file")
        return FileInfo(uri, finalName, size)
    }

    /** Отправляет один файл на телевизор. Вызывать не из главного потока. */
    fun send(ctx: Context, host: String, info: FileInfo, onProgress: (Long, Long) -> Unit) {
        var size = info.size
        var tmp: File? = null
        if (size < 0) {
            // Размер неизвестен — сначала копируем во временный файл.
            val t = File.createTempFile("send", null, ctx.cacheDir)
            tmp = t
            (ctx.contentResolver.openInputStream(info.uri) ?: throw IOException("Не удалось открыть файл"))
                .use { input -> t.outputStream().use { input.copyTo(it) } }
            size = t.length()
        }
        try {
            Socket().use { s ->
                s.connect(InetSocketAddress(host, TCP_PORT), 5000)
                s.soTimeout = 120000
                val out = DataOutputStream(BufferedOutputStream(s.getOutputStream(), 65536))
                out.writeUTF(MAGIC)
                out.writeUTF(info.name)
                out.writeLong(size)
                val t = tmp
                val input: InputStream = if (t != null) FileInputStream(t)
                else ctx.contentResolver.openInputStream(info.uri) ?: throw IOException("Не удалось открыть файл")
                input.use { inp ->
                    val buf = ByteArray(65536)
                    var sent = 0L
                    var last = 0L
                    while (sent < size) {
                        val n = inp.read(buf, 0, minOf(buf.size.toLong(), size - sent).toInt())
                        if (n < 0) break
                        out.write(buf, 0, n)
                        sent += n
                        val now = System.currentTimeMillis()
                        if (now - last > 200) {
                            last = now
                            onProgress(sent, size)
                        }
                    }
                    if (sent < size) throw IOException("Файл прочитан не полностью")
                }
                out.flush()
                onProgress(size, size)
                val answer = DataInputStream(s.getInputStream()).readByte().toInt()
                if (answer != 1) throw IOException("Телевизор не принял файл")
            }
        } finally {
            tmp?.delete()
        }
    }

    /** Копирует ровно size байт. */
    fun copyExact(input: InputStream, out: OutputStream, size: Long) {
        val buf = ByteArray(65536)
        var left = size
        while (left > 0) {
            val n = input.read(buf, 0, minOf(buf.size.toLong(), left).toInt())
            if (n < 0) throw IOException("Связь оборвалась")
            out.write(buf, 0, n)
            left -= n
        }
    }
}
