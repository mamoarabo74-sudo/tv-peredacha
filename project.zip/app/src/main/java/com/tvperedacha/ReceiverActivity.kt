package com.tvperedacha

import android.app.Activity
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.ScrollView

/** Экран на телевизоре. */
class ReceiverActivity : Activity() {
    private lateinit var list: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs().edit().putBoolean("receiver_enabled", true).apply()
        ReceiverService.start(this)
        if (Build.VERSION.SDK_INT >= 33) {
            try {
                requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
            } catch (e: Exception) {
            }
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(40), dp(30), dp(40), dp(30))
        }
        root.addView(label("📺 ТВ Передача", 30f, true))
        root.addView(label("Готов принимать файлы.\nНа телефоне откройте «ТВ Передача» и нажмите на этот телевизор.", 20f))
        val ips = Net.localIps().joinToString(", ").ifEmpty { "нет сети" }
        root.addView(label("Имя: ${Net.deviceName(this)}    IP: $ips", 16f))
        root.addView(label("Приём работает в фоне, даже если закрыть это окно.", 16f))
        root.addView(label("Полученные файлы:", 20f, true))
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(list)
        root.addView(bigButton("Отправлять с этого устройства") {
            prefs().edit().putString("mode", "send").apply()
            startActivity(Intent(this, SenderActivity::class.java))
            finish()
        })
        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        ReceiverService.listener = { r ->
            refresh()
            FileStore.open(this, r)
        }
        refresh()
    }

    override fun onPause() {
        ReceiverService.listener = null
        super.onPause()
    }

    private fun refresh() {
        list.removeAllViews()
        val items = synchronized(ReceiverService.received) { ReceiverService.received.toList() }
        if (items.isEmpty()) {
            list.addView(label("Пока ничего не получено", 16f))
            return
        }
        for (r in items.take(30)) {
            val icon = when {
                r.mime == FileStore.APK_MIME -> "📦"
                r.mime.startsWith("video") -> "🎬"
                r.mime.startsWith("image") -> "🖼"
                r.mime.startsWith("audio") -> "🎵"
                else -> "📄"
            }
            list.addView(bigButton("$icon  ${r.name}") { FileStore.open(this, r) })
        }
        list.getChildAt(0)?.requestFocus()
    }
}
