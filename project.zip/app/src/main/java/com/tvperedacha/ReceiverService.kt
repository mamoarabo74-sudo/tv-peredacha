package com.tvperedacha

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import java.io.BufferedInputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import kotlin.concurrent.thread

/** Работает на телевизоре в фоне и принимает файлы. */
class ReceiverService : Service() {

    companion object {
        private const val CHANNEL = "receiver"
        private const val CHANNEL_FILES = "files"

        val received = mutableListOf<FileStore.Received>()

        /** Если экран приложения открыт — он сам откроет полученный файл. */
        @Volatile
        var listener: ((FileStore.Received) -> Unit)? = null

        fun start(ctx: Context) {
            val i = Intent(ctx, ReceiverService::class.java)
            try {
                if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
            } catch (e: Exception) {
            }
        }
    }

    @Volatile
    private var running = false
    private var tcp: ServerSocket? = null
    private var udp: DatagramSocket? = null
    private var lock: WifiManager.MulticastLock? = null
    private val main = Handler(Looper.getMainLooper())
    private var notifId = 100

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startAsForeground()
        running = true
        try {
            val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            lock = wm.createMulticastLock("tvperedacha").apply {
                setReferenceCounted(false)
                acquire()
            }
        } catch (e: Exception) {
        }
        thread(name = "tcp") { tcpLoop() }
        thread(name = "udp") { udpLoop() }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        running = false
        try { tcp?.close() } catch (e: Exception) {}
        try { udp?.close() } catch (e: Exception) {}
        try { lock?.release() } catch (e: Exception) {}
        super.onDestroy()
    }

    private fun startAsForeground() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "Приём файлов", NotificationManager.IMPORTANCE_MIN))
            nm.createNotificationChannel(NotificationChannel(CHANNEL_FILES, "Полученные файлы", NotificationManager.IMPORTANCE_HIGH))
        }
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, ReceiverActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n: Notification = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle("ТВ Передача")
            .setContentText("Готов принимать файлы с телефона")
            .setContentIntent(open)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    private fun tcpLoop() {
        try {
            val ss = ServerSocket()
            ss.reuseAddress = true
            ss.bind(InetSocketAddress(Net.TCP_PORT))
            tcp = ss
            while (running) {
                val s = try {
                    ss.accept()
                } catch (e: Exception) {
                    break
                }
                thread { handle(s) }
            }
        } catch (e: Exception) {
        }
    }

    private fun handle(sock: Socket) {
        try {
            sock.use { s ->
                s.soTimeout = 60000
                val inp = DataInputStream(BufferedInputStream(s.getInputStream(), 65536))
                val out = DataOutputStream(s.getOutputStream())
                if (inp.readUTF() != Net.MAGIC) return
                val name = inp.readUTF()
                val size = inp.readLong()
                if (size < 0) return
                val r = FileStore.save(this, name, size, inp)
                out.writeByte(1)
                out.flush()
                synchronized(received) { received.add(0, r) }
                main.post { onReceived(r) }
            }
        } catch (e: Exception) {
        }
    }

    private fun onReceived(r: FileStore.Received) {
        val l = listener
        if (l != null) {
            l(r)
            return
        }
        // Приложение свёрнуто: пробуем открыть сразу (работает на многих ТВ) и показываем уведомление.
        try {
            startActivity(FileStore.viewIntent(r))
        } catch (e: Exception) {
        }
        try {
            val pi = PendingIntent.getActivity(
                this, notifId, FileStore.viewIntent(r),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val n = NotificationCompat.Builder(this, CHANNEL_FILES)
                .setSmallIcon(android.R.drawable.stat_sys_download_done)
                .setContentTitle("Получен файл")
                .setContentText(r.name)
                .setContentIntent(pi)
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .build()
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(notifId++, n)
        } catch (e: Exception) {
        }
    }

    private fun udpLoop() {
        try {
            val ds = DatagramSocket(null)
            ds.reuseAddress = true
            ds.broadcast = true
            ds.bind(InetSocketAddress(Net.UDP_PORT))
            udp = ds
            val buf = ByteArray(256)
            while (running) {
                val p = DatagramPacket(buf, buf.size)
                try {
                    ds.receive(p)
                } catch (e: Exception) {
                    break
                }
                val msg = String(p.data, 0, p.length, Charsets.UTF_8)
                if (msg == Net.FIND) {
                    val reply = (Net.HERE + "|" + Net.deviceName(this)).toByteArray(Charsets.UTF_8)
                    try {
                        ds.send(DatagramPacket(reply, reply.size, p.address, p.port))
                    } catch (e: Exception) {
                    }
                }
            }
        } catch (e: Exception) {
        }
    }
}
