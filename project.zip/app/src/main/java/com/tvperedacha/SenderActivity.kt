package com.tvperedacha

import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Parcelable
import android.text.InputType
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import kotlin.concurrent.thread

/** Экран на телефоне: найти телевизор и отправить файлы. */
class SenderActivity : Activity() {
    private val pending = mutableListOf<Uri>()
    private var tvs: List<Net.Tv> = emptyList()
    private var chosen: Net.Tv? = null
    @Volatile
    private var busy = false
    private val main = Handler(Looper.getMainLooper())

    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private lateinit var tvList: LinearLayout

    companion object {
        private const val PICK = 1
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(24))
        }
        root.addView(label("📺 Отправить на телевизор", 24f, true))
        status = label("", 17f)
        root.addView(status)
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 1000
            visibility = View.GONE
        }
        root.addView(progress)
        tvList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(tvList)
        root.addView(label(" ", 8f))
        root.addView(bigButton("🔄  Искать телевизоры снова") { search() })
        root.addView(bigButton("⌨️  Ввести IP телевизора вручную") { manualIp() })
        root.addView(bigButton("Принимать файлы на этом устройстве") {
            prefs().edit().putString("mode", "recv").apply()
            startActivity(Intent(this, ReceiverActivity::class.java))
            finish()
        })
        setContentView(ScrollView(this).apply { addView(root) })

        handleIntent(intent)
        search()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
        if (pending.isNotEmpty() && tvs.size == 1) sendTo(tvs[0]) else showTvs(tvs)
    }

    @Suppress("DEPRECATION")
    private fun handleIntent(i: Intent?) {
        if (i == null) return
        when (i.action) {
            Intent.ACTION_SEND -> {
                val u: Uri? = if (Build.VERSION.SDK_INT >= 33)
                    i.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
                else i.getParcelableExtra<Parcelable>(Intent.EXTRA_STREAM) as? Uri
                if (u != null) pending.add(u)
            }
            Intent.ACTION_SEND_MULTIPLE -> {
                val list: List<Uri>? = if (Build.VERSION.SDK_INT >= 33)
                    i.getParcelableArrayListExtra(Intent.EXTRA_STREAM, Uri::class.java)
                else i.getParcelableArrayListExtra<Parcelable>(Intent.EXTRA_STREAM)?.mapNotNull { it as? Uri }
                if (list != null) pending.addAll(list)
            }
        }
    }

    private fun search() {
        if (busy) return
        status.text = "Ищу телевизоры…"
        tvList.removeAllViews()
        thread {
            val found = Net.discover()
            main.post {
                showTvs(found)
                if (found.size == 1 && pending.isNotEmpty()) sendTo(found[0])
            }
        }
    }

    private fun showTvs(found: List<Net.Tv>) {
        val all = found.toMutableList()
        val manual = prefs().getString("manual_ip", null)
        if (!manual.isNullOrBlank() && all.none { it.host == manual }) all.add(Net.Tv("Телевизор", manual))
        tvs = all
        tvList.removeAllViews()
        if (busy) return
        status.text = when {
            all.isEmpty() -> "Телевизор не найден.\nПроверьте: телефон и ТВ в одной Wi‑Fi сети, а на ТВ хотя бы раз открыто «ТВ Передача»."
            pending.isNotEmpty() -> "Нажмите на телевизор, чтобы отправить (файлов: ${pending.size})"
            else -> "Нажмите на телевизор и выберите файлы"
        }
        for (tv in all) {
            tvList.addView(bigButton("📺  ${tv.name}   (${tv.host})") { onTv(tv) })
        }
    }

    private fun onTv(tv: Net.Tv) {
        if (busy) return
        if (pending.isNotEmpty()) {
            sendTo(tv)
            return
        }
        chosen = tv
        val pick = Intent(Intent.ACTION_OPEN_DOCUMENT)
            .addCategory(Intent.CATEGORY_OPENABLE)
            .setType("*/*")
            .putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        try {
            startActivityForResult(pick, PICK)
        } catch (e: ActivityNotFoundException) {
            val alt = Intent(Intent.ACTION_GET_CONTENT)
                .addCategory(Intent.CATEGORY_OPENABLE)
                .setType("*/*")
                .putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            startActivityForResult(alt, PICK)
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != PICK || resultCode != RESULT_OK || data == null) return
        val clip = data.clipData
        if (clip != null) {
            for (k in 0 until clip.itemCount) clip.getItemAt(k).uri?.let { pending.add(it) }
        } else {
            data.data?.let { pending.add(it) }
        }
        val tv = chosen
        if (tv != null && pending.isNotEmpty()) sendTo(tv)
    }

    private fun sendTo(tv: Net.Tv) {
        if (busy || pending.isEmpty()) return
        busy = true
        val files = pending.toList()
        pending.clear()
        tvList.removeAllViews()
        progress.progress = 0
        progress.visibility = View.VISIBLE
        thread {
            var ok = 0
            var error: String? = null
            files.forEachIndexed { idx, uri ->
                try {
                    val info = Net.queryInfo(this, uri)
                    main.post { status.text = "Отправляю ${idx + 1} из ${files.size}:\n${info.name}" }
                    Net.send(this, tv.host, info) { sent, total ->
                        main.post { progress.progress = if (total > 0) (sent * 1000 / total).toInt() else 0 }
                    }
                    ok++
                } catch (e: Exception) {
                    error = e.message ?: e.javaClass.simpleName
                }
            }
            main.post {
                busy = false
                progress.visibility = View.GONE
                showTvs(tvs)
                status.text = if (error == null) "Готово! Отправлено файлов: $ok ✅"
                else "Отправлено $ok из ${files.size}.\nОшибка: $error"
            }
        }
    }

    private fun manualIp() {
        val input = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_PHONE
            hint = "например 192.168.1.50"
            setText(prefs().getString("manual_ip", ""))
        }
        AlertDialog.Builder(this)
            .setTitle("IP телевизора")
            .setMessage("IP показан на экране «ТВ Передача» на телевизоре.")
            .setView(input)
            .setPositiveButton("OK") { _, _ ->
                val ip = input.text.toString().trim()
                if (ip.isNotEmpty()) {
                    prefs().edit().putString("manual_ip", ip).apply()
                    showTvs(tvs.filter { it.name != "Телевизор" })
                    onTv(Net.Tv("Телевизор", ip))
                }
            }
            .setNegativeButton("Отмена", null)
            .show()
    }
}
