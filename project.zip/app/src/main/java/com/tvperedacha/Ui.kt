package com.tvperedacha

import android.app.Activity
import android.content.Context
import android.content.SharedPreferences
import android.graphics.Typeface
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

fun Activity.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

fun Activity.prefs(): SharedPreferences = getSharedPreferences("settings", Context.MODE_PRIVATE)

fun Activity.label(s: String, size: Float = 18f, bold: Boolean = false): TextView =
    TextView(this).apply {
        text = s
        textSize = size
        if (bold) setTypeface(typeface, Typeface.BOLD)
        setPadding(0, dp(6), 0, dp(6))
    }

fun Activity.bigButton(s: String, onClick: () -> Unit): Button =
    Button(this).apply {
        text = s
        isAllCaps = false
        textSize = 18f
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(6) }
        setOnClickListener { onClick() }
    }
